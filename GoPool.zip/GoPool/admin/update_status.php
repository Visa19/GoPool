<?php
require_once '../classes/DbConnector.php';
require_once '../classes/User.php';
try {
    
    $dbConnector = new \classes\DbConnector();
    $dbh = $dbConnector->getConnection();
    
    // Instantiate User class
    $user = new \classes\User($dbh);
    
    // Check if userId and action are set
    if (isset($_POST['userId']) && isset($_POST['action'])) {
        $userId = intval($_POST['userId']);
        $action = $_POST['action'];

        // Perform action based on the received action parameter
        if ($action == 'confirm') {
            if ($user->confirmUser($userId)) {
                echo "success";
            } else {
                echo "error";
            }
        } elseif ($action == 'delete') {
            if ($user->deleteUser($userId)) {
                echo "deleted";
            } else {
                echo "error";
            }
        } else {
            echo "invalid action";
        }
    } else {
        echo "error";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

?>