<div class="brand clearfix">
	<a href="dashboard.php" style="font-size: 25px;">GoPool | Admin Panel</a>  
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#"><img src="https://th.bing.com/th/id/OIP.eVc5IIqjwSt5-V-OLr0HYgHaHY?rs=1&pid=ImgDetMain" class="ts-avatar hidden-side" alt=""> VSS <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="change-password.php">Change Password</a></li>
<!--                                        <li><a href="new_admin.php">Add Admin</a></li>-->
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
