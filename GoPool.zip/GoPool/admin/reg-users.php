<?php
require_once '../classes/DbConnector.php';

session_start();
error_reporting(0);

if(strlen($_SESSION['alogin'])==0)
{   
    header('location:index.php');
}
else {
    try {
        $dbConnector = new \classes\DbConnector();
        $dbh = $dbConnector->getConnection();
        
        // Handle the form submission for updating Stripe ID
        if(isset($_POST['user_id']) && isset($_POST['stripe_id'])) {
            $userId = $_POST['user_id'];
            $stripeId = $_POST['stripe_id'];

            $sql = "UPDATE tblusers SET StripeId = :stripeId WHERE id = :userId";
            $query = $dbh->prepare($sql);
            $query->bindParam(':stripeId', $stripeId, PDO::PARAM_STR);
            $query->bindParam(':userId', $userId, PDO::PARAM_INT);
            if ($query->execute()) {
                $msg = "Stripe ID updated successfully";
            } else {
                $error = "Failed to update Stripe ID";
            }
        }

        // Handle the user status update
        if(isset($_POST['userId']) && isset($_POST['action'])) {
            $userId = $_POST['userId'];
            $action = $_POST['action'];
            
            if ($action === 'confirm') {
                $sql = "UPDATE tblusers SET Status = 'Confirmed' WHERE id = :userId";
                $query = $dbh->prepare($sql);
                $query->bindParam(':userId', $userId, PDO::PARAM_INT);
                $query->execute();
                echo "success";
            } elseif ($action === 'delete') {
                $sql = "DELETE FROM tblusers WHERE id = :userId";
                $query = $dbh->prepare($sql);
                $query->bindParam(':userId', $userId, PDO::PARAM_INT);
                $query->execute();
                echo "deleted";
            } else {
                echo "invalid_action";
            }
            exit;
        }

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>GoPooll | Admin Manage Users</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <!-- Font awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- Sandstone Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap Datatables -->
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <!-- Bootstrap social button library -->
    <link rel="stylesheet" href="css/bootstrap-social.css">
    <!-- Bootstrap select -->
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <!-- Bootstrap file input -->
    <link rel="stylesheet" href="css/fileinput.min.css">
    <!-- Awesome Bootstrap checkbox -->
    <link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
    <!-- Admin Style -->
    <link rel="stylesheet" href="css/style.css">
    <style>
        .errorWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #dd3d36;
            -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .succWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #5cb85c;
            -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        /* The Modal (background) */
        .modal_img {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            padding-top: 100px; /* Location of the box */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }
        /* Modal Content */
        .modal-content {
            margin: auto;
            display: block;
            width: 80%; /* Default width */
            max-width: 300px; /* Max width */
            border-radius: 8px; /* Rounded corners */
            background-color: white; /* White background */
            padding: 20px; /* Padding inside the modal */
            box-shadow: 0 5px 15px rgba(0,0,0,0.3); /* Shadow for the modal */
        }
        /* The Close Button */
        .close {
            color: red;
            float: right;
            font-size: 30px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .modal-image {
            width: 100%; /* Image width to fit the modal */
            border-radius: 8px;
            transition: transform 0.25s ease; /* Smooth zoom effect */
            cursor: zoom-in;
        }
        /* Zoomed image */
        .modal-image.zoomed {
            cursor: zoom-out;
            transform: scale(2); /* Zoom level */
        }
        /* Table Scroll */
        .table-container {
            overflow-x: auto; /* Enable horizontal scroll */
        }
    </style>
</head>
<body>
    <?php include('includes/header.php');?>

    <div class="ts-main-content">
        <?php include('includes/leftbar.php');?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">

                        <h2 class="page-title">Registered Users</h2>

                        <!-- Zero Configuration Table -->
                        <div class="panel panel-default">
                            <div class="panel-heading">Registered Users</div>
                            <div class="panel-body">
                                <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
                                <div class="table-container">
                                    <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Contact no</th>
                                                <th>DOB</th>
                                                <th>Address</th>
                                                <th>Selfie Image</th>
                                                <th>NIC/ Licence</th>
                                                <th>Status</th>
                                                <th>Reg Date</th>
                                                <th>Stripe ID</th> <!-- New Column -->
                                                <th>Action</th> <!-- New Column for Adding Stripe ID -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sql = "SELECT * FROM tblusers";
                                            $query = $dbh->prepare($sql);
                                            $query->execute();
                                            $users = $query->fetchAll(PDO::FETCH_OBJ);

                                            if ($users) {
                                                $cnt = 1;
                                                foreach ($users as $result) {
                                                    ?>
                                                    <tr id="row-<?php echo htmlentities($result->id); ?>">
                                                        <td><?php echo htmlentities($cnt); ?></td>
                                                        <td><?php echo htmlentities($result->FullName); ?></td>
                                                        <td><?php echo htmlentities($result->EmailId); ?></td>
                                                        <td><?php echo htmlentities($result->ContactNo); ?></td>
                                                        <td><?php echo htmlentities($result->DOB); ?></td>
                                                        <td><?php echo htmlentities($result->Address); ?></td>
                                                        <td>
                                                            <img src="img/Users/<?php echo htmlentities($result->Selfie); ?>" width="50" height="50" style="border:solid 1px #000" onclick="openModal('<?php echo htmlentities($result->Selfie); ?>')">
                                                        </td>
                                                        <td>
                                                            <img src="img/Users/<?php echo htmlentities($result->NIC); ?>" width="50" height="50" style="border:solid 1px #000" onclick="openModal('<?php echo htmlentities($result->NIC); ?>')">
                                                        </td>
                                                        <td id="status-<?php echo htmlentities($result->id); ?>">
                                                            <?php echo htmlentities($result->Status); ?>
                                                            <?php if ($result->Status != "Confirmed") { ?>
                                                                <button class="btn btn-primary" onclick="updateStatus(<?php echo htmlentities($result->id); ?>)">Change Status</button>
                                                            <?php } ?>
                                                        </td>
                                                        <td><?php echo htmlentities($result->RegDate); ?></td>
                                                        <td><?php echo htmlentities($result->StripeId); ?></td> <!-- Display Stripe ID -->
                                                        <td>
                                                            <!-- Form for Adding Stripe ID -->
                                                            <form method="post" action="">
                                                                <input type="hidden" name="user_id" value="<?php echo htmlentities($result->id); ?>">
                                                                <input type="text" name="stripe_id" value="<?php echo htmlentities($result->StripeId); ?>" placeholder="Enter Stripe ID">
                                                                <button type="submit" class="btn btn-info">Update Stripe ID</button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                    $cnt++;
                                                }
                                            } else {
                                                echo "No users found.";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <div id="imageModal" class="modal_img">
        <span class="close" onclick="closeModal()">&times;</span>
        <div class="modal-content">
            <img id="modalImage" class="modal-image" src="">
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
    <script src="js/fileinput.js"></script>
    <script src="js/awesome-bootstrap-checkbox.js"></script>
    <script src="js/main.js"></script>

    <script>
        function openModal(imageSrc) {
            var modal = document.getElementById("imageModal");
            var modalImg = document.getElementById("modalImage");
            modal.style.display = "block";
            modalImg.src = "img/Users/" + imageSrc;
        }

        function closeModal() {
            var modal = document.getElementById("imageModal");
            modal.style.display = "none";
        }

        $(document).ready(function() {
            $('#zctb').DataTable();
        });

        function updateStatus(userId) {
            $.ajax({
                type: "POST",
                url: "manage_users.php",
                data: { userId: userId, action: 'confirm' },
                success: function(response) {
                    if (response === "success") {
                        $('#status-' + userId).html('Confirmed');
                    } else {
                        alert('Failed to update status');
                    }
                }
            });
        }
    </script>
<?php } ?>
</body>
</html>
