<?php

require_once '../classes/DbConnector.php';

use classes\DbConnector;

try {
    $dbConnector = new DbConnector();
    $conn = $dbConnector->getConnection();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Fetch income for Ride (10% of the total amount)
$rideQuery = "SELECT SUM(amount) * 0.1 as ride_income, SUM(amount) as total_ride_amount FROM tblpayments WHERE service_type = 'Ride'";
$rideResult = $conn->query($rideQuery);
$rideRow = $rideResult->fetch(PDO::FETCH_ASSOC);
$rideIncomeLKR = $rideRow['ride_income'];
$totalRideAmountLKR = $rideRow['total_ride_amount'] * 0.1;

// Fetch income for Rental (100% of the total amount)
$rentalQuery = "SELECT SUM(amount) as rental_income FROM tblpayments WHERE service_type = 'Rental'";
$rentalResult = $conn->query($rentalQuery);
$rentalRow = $rentalResult->fetch(PDO::FETCH_ASSOC);
$rentalIncomeLKR = $rentalRow['rental_income'];

// Fetch total amount for Rental
$totalRentalQuery = "SELECT SUM(amount) as total_rental_amount FROM tblpayments WHERE service_type = 'Rental'";
$totalRentalResult = $conn->query($totalRentalQuery);
$totalRentalRow = $totalRentalResult->fetch(PDO::FETCH_ASSOC);
$totalRentalAmountLKR = $totalRentalRow['total_rental_amount'];

// Calculate total income
$totalIncomeLKR = $rideIncomeLKR + $rentalIncomeLKR;

$data = array(
    'ride_income' => $rideIncomeLKR,
    'rental_income' => $rentalIncomeLKR,
    'total_income' => $totalIncomeLKR,
    'total_ride_amount' => $totalRideAmountLKR,
    'total_rental_amount' => $totalRentalAmountLKR
);

$conn = null;  // Close the database connection

?>

<!DOCTYPE html>
<html>
<head>
    <title>Income Charts</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <!-- Font awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
    
    
    
    <!-- Admin Style -->
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 30px;
        }
        h2 {
            color: #333;
            margin-bottom: 30px;
        }
        .chart-container {
            display: flex;
            justify-content: center;
            gap: 40px; /* Increased gap for better spacing */
            flex-wrap: wrap;
            padding: 20px;
        }
        .chart-box {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            padding: 30px; /* Increased padding for better layout */
            width: 400px; /* Increased width for more space */
            height: 400px; /* Increased height for more space */
            margin: 10px;
            position: relative;
        }
        .chart-box h3 {
            margin-top: 0;
        }
        .chart-box p {
            margin-bottom: 20px;
            font-size: 16px; /* Increased font size for better readability */
            color: #555;
        }
        .total-income {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            padding: 30px; /* Increased padding for better layout */
            margin: 30px auto;
            width: 400px; /* Increased width for more space */
        }
        .total-income h3 {
            margin-top: 0;
        }
        .total-income p {
            font-size: 22px; /* Increased font size for better visibility */
            color: #007bff; /* Changed color to blue */
        }
        .button-container {
            margin: 20px auto;
        }
        .btn {
            background-color: #007bff;
            color: #fff;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
   

    <div class="ts-main-content">
      
<!--    <h2>Income Charts in LKR</h2>-->
    <div class="chart-container">
        <div class="chart-box">
            <h3>Ride Income</h3>
            <p>Total Ride Income (10%): LKR <?php echo number_format($totalRideAmountLKR, 2); ?></p>
            <canvas id="rideIncomeChart" width="400" height="350"></canvas>
        </div>
        <div class="chart-box">
            <h3>Rental Income</h3>
            <p>Total Rental Amount: LKR <?php echo number_format($totalRentalAmountLKR, 2); ?></p>
            <canvas id="rentalIncomeChart" width="400" height="350"></canvas>
        </div>
    </div>
    <div class="total-income">
        <h3>Total Income</h3>
        <p>LKR <?php echo number_format($totalIncomeLKR, 2); ?></p>
    </div>
    <div class="button-container">
        <form action="income_pdf.php" method="post">
            <input type="hidden" name="ride_income" value="<?php echo $data['ride_income']; ?>">
            <input type="hidden" name="rental_income" value="<?php echo $data['rental_income']; ?>">
            <input type="hidden" name="total_income" value="<?php echo $data['total_income']; ?>">
            <input type="hidden" name="total_ride_amount" value="<?php echo $data['total_ride_amount']; ?>">
            <input type="hidden" name="total_rental_amount" value="<?php echo $data['total_rental_amount']; ?>">
            <button type="submit" class="btn">Download as PDF</button>
        </form>
    </div>
    <script>
        // Chart.js Data
        const data = <?php echo json_encode($data); ?>;

        // Ride Income Chart
        const rideCtx = document.getElementById('rideIncomeChart').getContext('2d');
        new Chart(rideCtx, {
            type: 'bar',
            data: {
                labels: ['Ride Income'],
                datasets: [{
                    label: 'Ride Income in LKR',
                    data: [data.ride_income],
                    backgroundColor: 'rgba(255, 99, 132, 0.7)', // Red color
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Income in LKR'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Service Type'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return `Ride Income: LKR ${tooltipItem.raw.toFixed(2)}`;
                            }
                        }
                    }
                }
            }
        });

        // Rental Income Chart
        const rentalCtx = document.getElementById('rentalIncomeChart').getContext('2d');
        new Chart(rentalCtx, {
            type: 'bar',
            data: {
                labels: ['Rental Income'],
                datasets: [{
                    label: 'Rental Income in LKR',
                    data: [data.rental_income],
                    backgroundColor: 'rgba(54, 162, 235, 0.7)', // Blue color
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Income in LKR'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Service Type'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return `Rental Income: LKR ${tooltipItem.raw.toFixed(2)}`;
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
