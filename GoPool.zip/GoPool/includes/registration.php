<?php

include '../classes/DbConnector.php';
include '../classes/User.php';

try {
    $dbConnector = new \classes\DbConnector();
    $dbh = $dbConnector->getConnection();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

if (isset($_POST['signup'])) {
    // Sanitize inputs
    $fullname = htmlspecialchars($_POST['fullname']);
    $email = htmlspecialchars($_POST['emailid']);
    $mobile = htmlspecialchars($_POST['mobileno']);
    $user_password = $_POST['password'];
    $address = htmlspecialchars($_POST['address']);
    $dob = htmlspecialchars($_POST['dob']);
    $password = password_hash($user_password, PASSWORD_BCRYPT);
    $uploadDir = 'admin/img/Users/';
    $nicImageName = basename($_FILES["nic_image"]["name"]);
    $selfieImageName = basename($_FILES["selfie_image"]["name"]);
    $nicImagePath = $uploadDir . $nicImageName;
    $selfieImagePath = $uploadDir . $selfieImageName;

    move_uploaded_file($_FILES["nic_image"]["tmp_name"], $nicImagePath);
    move_uploaded_file($_FILES["selfie_image"]["tmp_name"], $selfieImagePath);
    
    $sql = "INSERT INTO tblusers (FullName, EmailId, Password, ContactNo, DOB, Address, Selfie, NIC) 
                    VALUES (:fullname, :email, :password, :contactno, :dob, :address, :selfie_image, :nic_image)";
            $stmt = $dbh->prepare($sql);
            $stmt->bindParam(':fullname', $fullname, PDO::PARAM_STR);
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            $stmt->bindParam(':password', $password, PDO::PARAM_STR);
            $stmt->bindParam(':contactno', $mobile, PDO::PARAM_STR);
            $stmt->bindParam(':dob', $dob, PDO::PARAM_STR);
            $stmt->bindParam(':address', $address, PDO::PARAM_STR);
            $stmt->bindParam(':selfie_image', $selfieImageName, PDO::PARAM_STR); // Store only the image name
            $stmt->bindParam(':nic_image', $nicImageName, PDO::PARAM_STR); // Store only the image name
            $stmt->execute();

            $lastInsertId = $dbh->lastInsertId();
            if ($lastInsertId) {
                $message= "<h6 class='text-danger' style='color: green'; font-size: 16px;>Account Created Sucessfully Wait For Admin Approval.</h6>";
            } else {
                $message= "<h6 class='text-danger' style='color: red'; font-size: 16px;>Account Failed To Create.</h6>";
                file_put_contents($logFile, "Database insertion failed for user: $fullname\n", FILE_APPEND);
            }
}
?>
<script>
function checkAvailability() {
    $("#loaderIcon").show();
    jQuery.ajax({
        url: "check_availability.php",
        data: 'emailid=' + $("#emailid").val(),
        type: "POST",
        success: function(data) {
            $("#user-availability-status").html(data);
            $("#loaderIcon").hide();
        },
        error: function() {}
    });
}



$(document).ready(function() {
    $('#nic_image').change(function() {
        previewImage(this, 'nic_image_preview');
    });

    $('#selfie_image').change(function() {
        previewImage(this, 'selfie_image_preview');
    });
});
</script>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', (event) => {
    var password = document.forms["signup"]["password"];
    var confirmPassword = document.forms["signup"]["confirmpassword"];
    var message = document.getElementById('password-message');
    
    function validatePassword() {
        if (password.value !== confirmPassword.value) {
            confirmPassword.setCustomValidity("Passwords do not match.");
            message.textContent = "Passwords do not match. Please try again.";
            message.style.color = 'red';
        } else {
            confirmPassword.setCustomValidity("");
            message.textContent = "Passwords match.";
            message.style.color = 'green';
        }
    }
    
    password.addEventListener('input', validatePassword);
    confirmPassword.addEventListener('input', validatePassword);
});

document.getElementById('mobileno').addEventListener('input', function (e) {
  var inputField = e.target;
  var value = inputField.value;
  var errorMessage = document.getElementById('error-message');

  // Check if the input contains non-digit characters
  if (/^\d*$/.test(value)) {
    // Hide error message if input is valid
    errorMessage.style.display = 'none';
  } else {
    // Show error message if input is invalid
    errorMessage.style.display = 'block';
    
    // Remove non-digit characters from the input
    inputField.value = value.replace(/\D/g, '');
  }
});
</script>
<style>
.modal-body {
    max-height: 70vh; 
    overflow-y: auto;
    overflow-x: hidden;
}
.custom-file-input {
    display: none;
}
.custom-file-label {
    border: 1px solid #ced4da;
    display: inline-block;
    padding: 0.5rem 1rem;
    cursor: pointer;
    border-radius: 4px;
    background-color: #f8f9fa;
}
.custom-file-label:hover {
    background-color: #e2e6ea;
}
.image-preview {
    max-height: 100px;
    margin-top: 10px;
    display: none; /* Initially hide the image preview */
}
</style>
<div class="modal fade" id="signupform">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Sign Up</h3>
      </div>
        <?php echo $message; ?>
      <div class="modal-body">
        <div class="row">
          <div class="signup_wrap">
            <div class="col-md-12 col-sm-6">
              <form method="post" enctype="multipart/form-data" name="signup">

                <div class="form-group">
                  <input type="text" class="form-control" name="fullname" placeholder="Full Name" required="required">
                </div>

                  <div class="form-group">
                      <input type="text" class="form-control" id="mobileno" name="mobileno" placeholder="Mobile Number" maxlength="10" required>
                      <small id="error-message" style="color: red; display: none;">Please enter only numbers.</small>
                  </div>
                  <div class="form-group">
                  <input type="email" class="form-control" name="emailid" id="emailid" onBlur="checkAvailability()" placeholder="Email Address" required="required">
                  <span id="user-availability-status" style="font-size:12px;"></span> 
                </div>
                <div class="form-group">
                  <input type="date" class="form-control" name="dob" id="dob" placeholder="Date Of Birth" required="required">
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="address" placeholder="Address" maxlength="70" required="required">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" name="password" placeholder="Password" required="required">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" name="confirmpassword" placeholder="Confirm Password" required="required">
                  <span id="password-message"></span>
                </div>
                <div class="form-group">
                  <label class="custom-file-label" for="nic_image">Upload Your Front Of NIC or Driving License</label>
                  <input type="file" class="custom-file-input" name="nic_image" id="nic_image" required="required">
                
                </div>
                <div class="form-group">
                  <label class="custom-file-label" for="selfie_image">Upload Your Selfie or Front Facing Image</label>
                  <input type="file" class="custom-file-input" name="selfie_image" id="selfie_image" required="required">
                 
                </div>
                <div class="form-group checkbox">
                  <input type="checkbox" id="terms_agree" required="required" checked="">
                  <label for="terms_agree">I Agree with <a href="page.php?type=terms">Terms and Conditions</a></label>
                </div>
                <div class="form-group">
                  <input type="submit" value="Sign Up" name="signup" id="submit" class="btn btn-block">
                </div>
              </form>
            </div>
            
          </div>
        </div>
      </div>
      <div class="modal-footer text-center">
        <p>Already got an account? <a href="#loginform" data-toggle="modal" data-dismiss="modal">Login Here</a></p>
      </div>
    </div>
  </div>
</div>
